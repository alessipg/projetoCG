#include "ponto.h"

Ponto::Ponto(float x, float y):x(x), y(y), xWin(x),yWin(y),coordW(1){}
