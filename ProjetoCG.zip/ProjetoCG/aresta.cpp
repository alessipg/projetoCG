#include "aresta.h"

Aresta::Aresta(Ponto *a, Ponto *b): a(a), b(b){}
